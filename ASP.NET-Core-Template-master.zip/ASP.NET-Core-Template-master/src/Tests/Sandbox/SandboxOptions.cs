﻿namespace Sandbox
{
    using CommandLine;

    [Verb("sandbox", HelpText = "Run sandbox code.")]
    public class SandboxOptions
    {
    }
}
